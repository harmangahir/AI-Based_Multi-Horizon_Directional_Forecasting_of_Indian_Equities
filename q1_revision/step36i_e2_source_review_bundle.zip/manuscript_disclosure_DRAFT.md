# Step 36I-E1 — Methodological amendment review

**Status: DRAFT — NOT APPROVED**

## Original evaluation design

The Step-35 contract specified 6,480 common multitask observations
over 324 sessions, with 20 equities, three forecasting horizons,
40 final-development checkpoints and 24 frozen decision thresholds.

## Identified technical discrepancy

The original structural target-eligibility criterion did not additionally
enforce the complete 60-session same-segment predictor-history requirement.
The independently audited continuity and feature-warm-up boundaries
result in 1,180 structurally target-eligible observations without a
valid complete input sequence.

## Proposed corrected evaluation population

The candidate cohort contains 5,300 observations over 265 sessions:
48 sessions in the first continuity segment and 217 in the second.
The exclusion represents 18.21% of the original
6,480 observations. The candidate key file is SHA256-bound.

This correction was documented after the Step-35 contract was frozen;
it must not be described as part of the original prespecified protocol.

## Model and statistical controls

No model reselection, checkpoint retraining, best-seed selection,
or threshold reoptimization is proposed. The 40 fitted checkpoints,
eight architectures, five seeds, 60-session lookback and 24 thresholds
remain unchanged.

The proposed inference method uses date-clustered,
segment-stratified circular moving-block bootstrap sampling, preserving
20-stock cross-sections and the 48:217 date allocation. L=20 is the
proposed primary block length; L=10 and L=40 are sensitivities,
with 2,000 bootstrap replications per length. The primary
multiple-testing family contains 24 architecture-horizon tests.

This statistical amendment requires independent methodological review.

## Held-out data-access disclosure

Two physical raw-test accesses occurred during unsuccessful technical
materialization attempts. Held-out labels were parsed/validated in
the execution pathway, but no held-out performance metric was produced.
No additional raw-test access is currently authorized.

## Pending scientific decisions

The cohort correction, inferential assumptions, confirmatory versus
exploratory status and any further sealed-test read require explicit
review and approval before real-data scoring.

**Synthetic preflight results are not empirical forecasting results.**
