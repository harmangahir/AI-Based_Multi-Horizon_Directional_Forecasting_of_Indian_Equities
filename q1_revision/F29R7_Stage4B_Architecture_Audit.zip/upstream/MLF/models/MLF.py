__all__ = ['MLF.py']

# Cell
import time
from typing import Callable, Optional
import torch
from torch import nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np

from layers.MLF_backbone import MLF_backbone
from layers.RevIN import RevIN
class Model(nn.Module):
    def __init__(self, configs, max_seq_len:Optional[int]=1024, d_k:Optional[int]=None, d_v:Optional[int]=None, norm:str='BatchNorm', attn_dropout:float=0., 
                 act:str="gelu", key_padding_mask:bool='auto',padding_var:Optional[int]=None, attn_mask:Optional[Tensor]=None, res_attention:bool=True, 
                 pre_norm:bool=False, store_attn:bool=False, pe:str='zeros', learn_pe:bool=True, pretrain_head:bool=False, head_type = 'flatten', verbose:bool=False, **kwargs):
        
        super().__init__()

        c_in = configs.enc_in
        context_window=configs.context_window
        target_window = configs.pred_len
        
        n_layers = configs.e_layers
        n_heads = configs.n_heads
        d_model = configs.d_model
        d_ff = configs.d_ff
        dropout = configs.dropout
        fc_dropout = configs.fc_dropout
        head_dropout = configs.head_dropout

        individual = configs.individual

        patch_len = configs.patch_len
        stride = configs.stride
        padding_patch = configs.padding_patch

        revin = configs.revin
        affine = configs.affine
        subtract_last = configs.subtract_last
        self.configs=configs

        self.model = MLF_backbone(configs=configs,c_in=c_in, context_window = context_window, target_window=target_window, patch_len=patch_len, stride=stride,
                              max_seq_len=max_seq_len, n_layers=n_layers, d_model=d_model,
                              n_heads=n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, norm=norm, attn_dropout=attn_dropout,
                              dropout=dropout, act=act, key_padding_mask=key_padding_mask, padding_var=padding_var,
                              attn_mask=attn_mask, res_attention=res_attention, pre_norm=pre_norm, store_attn=store_attn,
                              pe=pe, learn_pe=learn_pe, fc_dropout=fc_dropout, head_dropout=head_dropout, padding_patch = padding_patch,
                              pretrain_head=pretrain_head, head_type=head_type, individual=individual, revin=revin, affine=affine,
                              subtract_last=subtract_last, verbose=verbose, **kwargs)

        self.D_norm=configs.D_norm
        if self.configs.revin_norm:
            self.configs.revin_layer = RevIN(self.configs.enc_in, affine=self.configs.affine,
                                                subtract_last=self.configs.subtract_last)
    def forward(self,x, x_mark_enc, x_dec, x_mark_dec):           # x: [Batch, Input length, Channel]
        scal_x_all=[]
        self.configs.bs=x.shape[0]

        if self.D_norm:
            seq_last = x[:, -1:, :].detach()
            self.configs.seq_last = seq_last
            x = x - seq_last
        elif self.configs.revin_norm:
            x=self.configs.revin_layer(x, 'norm')

        for i,s in enumerate(self.configs.scal_all):
        # for i, s in enumerate(self.scal_temp):
            if i==0:
                scal_x_all.append(x[:,-s:,:].permute(0,2,1))
            else:
                scal_x_all.append(x[:, -s:, :].permute(0,2,1))

        x,scale_all_rec,scale_all_patch= self.model(scal_x_all)

        if self.D_norm: #DLinear Norm
            x = x + seq_last

        return x,scale_all_rec,scale_all_patch
